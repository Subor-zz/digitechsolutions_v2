# Digitech Solutions — copywriting handoff

## Opdracht

Lees eerst het actuele prototype en de documentatie. Schrijf daarna een complete Nederlandse copylaag die past in de bestaande componentstructuur, sectievolgorde, CTA's, motion en desktop-/mobiele ervaring.

De huidige prototypebron staat in:

- `app/prototype/rebrand/page.tsx`
- `components/rebrand/`
- `lib/rebrand/content.ts`
- `app/globals.css`

De eerder genoemde map `app/prototype/four-act-homepage/` bestaat niet in deze repository. Gebruik daarom de bovenstaande actuele implementatie als bron van waarheid voor beschikbare ruimte en componenten.

## Leesvolgorde en prioriteit

Lees minimaal:

1. `docs/PROJECT_BRIEF.md`
2. `docs/POSITIONING.md`
3. `docs/REQUIREMENTS.md`
4. `docs/STORYLINE.md`
5. `docs/DESIGN_DIRECTION.md`
6. `docs/MODERNIZATION_SCAN.md`
7. `docs/DECISIONS.md`

Bij conflicten geldt: recente `LOCKED` beslissing in `DECISIONS.md` → requirements → projectbrief → storyline/designrichting → bestaande prototypecopy.

## Placeholders zijn toegestaan

Commerciële of persoonlijke feiten die nog niet zijn vastgesteld mogen placeholders blijven. Verzin geen prijzen, doorlooptijden, ervaringsjaren, certificaten, klantnamen, testimonials, resultaten of percentages.

Label onzekere copy expliciet als:

- `[NOG BEPALEN: ...]`
- `[BEWIJS NODIG: ...]`
- `[GOEDKEURING NODIG: ...]`
- `[CASE PLACEHOLDER: ...]`
- `[BESLISSING NODIG: ...]`

Alleen claims met status `APPROVED` of `APPROVED WITH QUALIFIER` in `docs/CLAIM_REGISTER.md` mogen als definitieve publieke claims worden behandeld. Lab- of conceptcases moeten zichtbaar als zodanig worden gelabeld.

## Gewenste output

Lever copy voor navigatie, hero, de volledige verhaallijn, sectieovergangen, workflow- en applicatieroutes, werkwijze, founder-led sectie, proof/cases, Modernization Scan, CTA's, formuliermicrocopy, footer, mobiele verkorte varianten en metadata/SEO.

Markeer ieder tekstblok als een van:

- `DEFINITIEF`
- `VOORLOPIG`
- `BEWIJS NODIG`
- `GOEDKEURING NODIG`

Behoud de strategische keuzes en verander geen merkpositionering stilzwijgend.
