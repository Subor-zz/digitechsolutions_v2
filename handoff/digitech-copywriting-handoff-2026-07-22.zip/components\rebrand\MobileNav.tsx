"use client";

import { useEffect, useState } from "react";

const navItems = [
  { href: "#probleem", label: "De frictie" },
  { href: "#diagnose", label: "Diagnose" },
  { href: "#routes", label: "Expertise" },
  { href: "#werkwijze", label: "Werkwijze" },
] as const;

export function MobileNav() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!open) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open]);

  return (
    <div className="mobile-nav">
      <button
        className="mobile-nav__toggle"
        type="button"
        aria-expanded={open}
        aria-controls="mobile-navigation"
        onClick={() => setOpen((current) => !current)}
      >
        <span>{open ? "Sluiten" : "Menu"}</span>
        <span className="mobile-nav__icon" aria-hidden="true">
          <i />
          <i />
        </span>
      </button>
      {open ? (
        <nav id="mobile-navigation" className="mobile-nav__panel" aria-label="Mobiele navigatie">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setOpen(false)}>
              {item.label}
            </a>
          ))}
          <a className="button button--primary" href="#scan" onClick={() => setOpen(false)}>
            Modernization Scan
          </a>
        </nav>
      ) : null}
    </div>
  );
}
