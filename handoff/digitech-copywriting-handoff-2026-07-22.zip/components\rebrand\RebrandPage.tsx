import { BrandLockup } from "./BrandLockup";
import { FlowDiagram } from "./FlowDiagram";
import { HeroSystemMap } from "./HeroSystemMap";
import { JourneyRoute } from "./JourneyRoute";
import { MethodStack } from "./MethodStack";
import { MobileNav } from "./MobileNav";
import { NarrativeMotion } from "./NarrativeMotion";
import { modernizationRoutes } from "@/lib/rebrand/content";

const diagnosisLayers = [
  {
    title: "Proces",
    description: "Waar ontstaat wachttijd, herwerk of een uitzondering die niemand expliciet bezit?",
  },
  {
    title: "Data",
    description: "Welke informatie wordt gekopieerd, ontbreekt of wijkt tussen bronnen van elkaar af?",
  },
  {
    title: "Systemen",
    description: "Welke applicaties en integraties begrenzen de route of vergroten de afhankelijkheid?",
  },
  {
    title: "Risico",
    description: "Waar raakt verandering continuïteit, privacy, beveiliging of operationele controle?",
  },
  {
    title: "Eigenaarschap",
    description: "Wie beslist, beheert uitzonderingen en kan na overdracht zelfstandig verder?",
  },
] as const;

export function RebrandPage() {
  return (
    <div className="site-shell">
      <NarrativeMotion />
      <a className="skip-link" href="#hoofdinhoud">
        Ga naar de hoofdinhoud
      </a>

      <header className="site-header">
        <a className="site-header__brand" href="#top">
          <BrandLockup />
        </a>
        <nav className="desktop-nav" aria-label="Hoofdnavigatie">
          <a href="#probleem">De frictie</a>
          <a href="#diagnose">Diagnose</a>
          <a href="#routes">Expertise</a>
          <a href="#werkwijze">Werkwijze</a>
        </nav>
        <a className="button button--header" href="#scan">
          Modernization Scan
        </a>
        <MobileNav />
      </header>

      <main id="hoofdinhoud" className="site-journey">
        <JourneyRoute />
        <div className="story-spike">
        <section
          id="top"
          className="hero chapter chapter--dark story-spike__hero"
          aria-labelledby="hero-heading"
        >
          <div className="hero__grid" aria-hidden="true" />
          <div className="container hero__layout">
            <div className="hero__copy">
              <p className="section-kicker section-kicker--light">
                Workflow- en applicatiemodernisering
              </p>
              <h1 id="hero-heading">Moderniseer wat je organisatie vertraagt.</h1>
              <p className="hero__lede">
                Digitech Solutions brengt vastgelopen workflows en verouderde
                bedrijfsapplicaties terug naar een beheersbare route. Eerst begrijpen, dan
                gericht moderniseren.
              </p>
              <div className="hero__actions">
                <a className="button button--primary" href="#scan">
                  Start met de Modernization Scan
                  <span aria-hidden="true">↘</span>
                </a>
                <a className="text-link text-link--light" href="#werkwijze">
                  Bekijk de werkwijze
                </a>
              </div>
              <p className="hero__founder">
                <span aria-hidden="true" />
                Rechtstreeks met Subor Cheung. Specialistische expertise wordt transparant
                toegevoegd waar die nodig is.
              </p>
            </div>

            <HeroSystemMap />
          </div>
        </section>

        <section
          id="probleem"
          className="chapter chapter--paper story-spike__problem"
          aria-labelledby="probleem-heading"
        >
          <div className="container problem-intro">
            <div>
              <p className="section-kicker">Herken de verborgen frictie</p>
              <h2 id="probleem-heading">De grootste vertraging zit vaak tussen je systemen.</h2>
            </div>
            <p className="chapter-intro">
              Niet in één medewerker of één applicatie, maar in overdrachten, workarounds,
              dubbele invoer en software die niet meer met de organisatie meegroeit.
            </p>
          </div>
          <div className="container">
            <div className="flow-diagram-stage">
              <FlowDiagram />
            </div>
          </div>
        </section>

        <section
          id="diagnose"
          className="chapter chapter--paper diagnosis story-spike__diagnosis"
          aria-labelledby="diagnose-heading"
        >
          <div className="container diagnosis__heading">
            <h2 id="diagnose-heading">Eerst begrijpen. Dan pas automatiseren of herbouwen.</h2>
            <p>
              De Modernization Scan onderzoekt vijf samenhangende lagen. Pas daarna wordt een
              route gekozen.
            </p>
          </div>
          <div className="container diagnosis__layout">
            <div className="diagnosis__layers">
              {diagnosisLayers.map((layer, index) => (
                <details key={layer.title} open={index === 0}>
                  <summary>
                    <span>{layer.title}</span>
                    <i aria-hidden="true" />
                  </summary>
                  <p>{layer.description}</p>
                </details>
              ))}
            </div>
            <aside className="diagnosis__route-note">
              <h3>De oplossing volgt uit het bewijs.</h3>
              <p>
                Vereenvoudigen, integreren, automatiseren of gericht vernieuwen blijven opties.
                Een volledige herbouw is nooit het automatische vertrekpunt.
              </p>
              <a className="text-link" href="#routes">
                Bekijk de expertise-routes <span aria-hidden="true">↓</span>
              </a>
            </aside>
          </div>
        </section>
        </div>

        <section id="routes" className="chapter chapter--dark routes" aria-labelledby="routes-heading">
          <div className="container routes__heading">
            <p className="section-kicker section-kicker--light">Eén vraag, twee expertise-routes</p>
            <h2 id="routes-heading">Waar zit de dragende beperking?</h2>
            <p>
              Je hoeft het antwoord nog niet zeker te weten. De route is een eerste hypothese,
              geen onomkeerbare diagnose.
            </p>
          </div>
          <div className="routes__grid">
            {modernizationRoutes.map((route) => (
              <article className="route-panel" key={route.id}>
                <div className="route-panel__topline">
                  <span>{route.title}</span>
                  <i aria-hidden="true" />
                </div>
                <h3>{route.statement}</h3>
                <ul>
                  {route.signals.map((signal) => (
                    <li key={signal}>{signal}</li>
                  ))}
                </ul>
                <p className="route-panel__output">{route.output}</p>
                <a className="text-link text-link--light" href="#scan">
                  Verken deze route <span aria-hidden="true">↘</span>
                </a>
              </article>
            ))}
            <aside className="combined-route">
              <div>
                <span className="combined-route__mark" aria-hidden="true" />
                <p>Workflow en applicatie zitten samen vast</p>
              </div>
              <p>
                Kies gecombineerd of onzeker. De intake vertrekt vanuit zichtbare symptomen,
                niet vanuit technische termen die je vooraf moet beheersen.
              </p>
              <a className="text-link text-link--light" href="#scan">
                Ik weet het nog niet
              </a>
            </aside>
          </div>
        </section>

        <section id="werkwijze" className="chapter chapter--ink method" aria-labelledby="werkwijze-heading">
          <div className="container">
            <MethodStack />
          </div>
        </section>

        <section className="chapter chapter--paper founder" aria-labelledby="founder-heading">
          <div className="container founder__layout">
            <div className="founder__identity" aria-hidden="true">
              <svg className="founder__route" viewBox="0 0 600 520">
                <path d="M32 112H186V260H304V416H566" />
                <path d="M32 364H118V260H304" />
                <circle cx="304" cy="260" r="7" />
                <circle cx="566" cy="416" r="7" />
              </svg>
              <span>S</span>
              <span>C</span>
              <i />
            </div>
            <div className="founder__copy">
              <h2 id="founder-heading">Geen overdracht naar een anoniem deliveryteam.</h2>
              <p className="founder__lead">
                Je werkt rechtstreeks met Subor Cheung: van analyse en functionele vertaling tot
                afstemming en overdracht.
              </p>
              <p>
                Waar een vraag specialistische diepgang nodig heeft, wordt die expertise
                transparant toegevoegd. De scope blijft zichtbaar en Digitech Solutions doet zich
                niet voor als een groot intern bureau.
              </p>
              <ul className="founder__capabilities">
                <li>Procesanalyse</li>
                <li>Functionele vertaling</li>
                <li>Productdenken</li>
                <li>Technische uitvoering</li>
                <li>Deliverycontrole</li>
                <li>Overdracht</li>
              </ul>
              <div className="founder__questions" aria-label="Veelgestelde vragen">
                <details>
                  <summary>Is de scan een verkoopgesprek?</summary>
                  <p>
                    Nee. De scan levert een zelfstandig bruikbare kaart van de huidige staat,
                    risico&apos;s en een gefaseerde route op.
                  </p>
                </details>
                <details>
                  <summary>Moet een oude applicatie volledig opnieuw?</summary>
                  <p>
                    Nee. Vereenvoudigen, integreren, beveiligen en gericht vernieuwen worden eerst
                    afgewogen.
                  </p>
                </details>
                <details>
                  <summary>Welke rol speelt AI?</summary>
                  <p>
                    AI kan de uitvoering versnellen. Scope, menselijke review, testen en
                    overdraagbaarheid blijven leidend.
                  </p>
                </details>
              </div>
              <a className="button button--primary founder__cta" href="#scan">
                Start met de Modernization Scan <span aria-hidden="true">↘</span>
              </a>
            </div>
          </div>
        </section>

        <section id="scan" className="chapter chapter--dark scan" aria-labelledby="scan-heading">
          <div className="container scan__layout">
            <div className="scan__copy">
              <h2 id="scan-heading">Je hoeft nog niet te weten wat er gebouwd moet worden.</h2>
              <p>
                Begin met het scherp krijgen van het probleem, de risico&apos;s en de meest verstandige
                route. De scan kiest de oplossing niet vooraf.
              </p>
              <div className="scan__actions">
                <a className="button button--primary" href="https://digitechsolutions.nl/contact">
                  Start met de Modernization Scan
                  <span aria-hidden="true">↗</span>
                </a>
                <p>Prototype: er wordt hier geen formulierdata verzameld of verzonden.</p>
              </div>
            </div>
            <div className="scan-roadmap" aria-label="Beoogde output van de Modernization Scan">
              <div>
                <span>Huidige staat</span>
                <strong>Proces, systemen en afhankelijkheden in één kaart</strong>
              </div>
              <i aria-hidden="true" />
              <div>
                <span>Beslissingen</span>
                <strong>Frictie, risico, opties en expliciete aannames</strong>
              </div>
              <i aria-hidden="true" />
              <div>
                <span>Eerste stap</span>
                <strong>Een gefaseerde route met duidelijke grenzen</strong>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container site-footer__top">
          <BrandLockup />
          <p>Workflow- en applicatiemodernisering voor organisaties die weer grip willen op verandering.</p>
          <a className="text-link text-link--light" href="#top">
            Terug naar boven <span aria-hidden="true">↑</span>
          </a>
        </div>
        <div className="container site-footer__bottom">
          <span>Rebrandprototype, juli 2026</span>
          <span>Niet geïndexeerd. Geen analytics. Geen formulierverwerking.</span>
        </div>
      </footer>
    </div>
  );
}
