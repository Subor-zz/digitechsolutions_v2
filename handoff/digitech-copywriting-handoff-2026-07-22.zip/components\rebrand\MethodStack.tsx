import { methodSteps } from "@/lib/rebrand/content";

const methodPhases = [
  {
    title: "Begrijpen",
    steps: methodSteps.slice(0, 2),
    description:
      "Doel, proces, data, systemen en risico's komen samen in één gedeeld beeld.",
    artifact: "Scopekader en current-state map",
  },
  {
    title: "Gericht moderniseren",
    steps: methodSteps.slice(2, 4),
    description:
      "Onnodige complexiteit verdwijnt eerst. Daarna wordt alleen de afgebakende verbetering gebouwd.",
    artifact: "Beslislog en werkende moderniseringsstap",
  },
  {
    title: "Borgen",
    steps: methodSteps.slice(4, 6),
    description:
      "Acceptatie, risico, documentatie en overdracht maken de verandering controleerbaar.",
    artifact: "Controlebewijs en overdrachtsset",
  },
] as const;

export function MethodStack() {
  return (
    <div className="method-stack">
      <div className="method-stack__intro">
        <h2 id="werkwijze-heading">Snel waar het kan. Gecontroleerd waar het moet.</h2>
        <p>
          Zes stappen blijven onderdeel van de aanpak, maar de klantreis draait om drie heldere
          beslismomenten.
        </p>
      </div>
      <div className="method-route" aria-hidden="true">
        <span className="method-route__line" />
        {methodSteps.map((step) => (
          <i key={step.id} />
        ))}
      </div>
      <ol className="method-phases">
        {methodPhases.map((phase) => (
          <li className="method-phase" key={phase.title}>
            <ol className="method-phase__steps" aria-label={`Stappen binnen ${phase.title}`}>
              {phase.steps.map((step) => {
                const stepNumber = methodSteps.findIndex((item) => item.id === step.id) + 1;

                return (
                  <li key={step.id}>
                    <span className="method-phase__step-index" aria-hidden="true">
                      {String(stepNumber).padStart(2, "0")}
                    </span>
                    <span className="method-phase__step-name">{step.title}</span>
                  </li>
                );
              })}
            </ol>
            <div>
              <h3>{phase.title}</h3>
              <p>{phase.description}</p>
              <p className="method-phase__artifact">{phase.artifact}</p>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
