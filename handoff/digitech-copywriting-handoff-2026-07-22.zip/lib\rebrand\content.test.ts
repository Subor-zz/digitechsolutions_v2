import { describe, expect, it } from "vitest";

import {
  bannedMarketingPhrases,
  methodSteps,
  modernizationRoutes,
} from "./content";

const publicCopy = JSON.stringify({ methodSteps, modernizationRoutes }).toLowerCase();

describe("rebrand content model", () => {
  it("keeps route and method identifiers unique", () => {
    expect(new Set(modernizationRoutes.map((route) => route.id)).size).toBe(
      modernizationRoutes.length,
    );
    expect(new Set(methodSteps.map((step) => step.id)).size).toBe(methodSteps.length);
  });

  it("contains the complete controlled-delivery sequence", () => {
    expect(methodSteps.map((step) => step.id)).toEqual([
      "scope",
      "map",
      "simplify",
      "build",
      "verify",
      "transfer",
    ]);
  });

  it("does not contain banned marketing phrases", () => {
    for (const phrase of bannedMarketingPhrases) {
      expect(publicCopy).not.toContain(phrase.toLowerCase());
    }
  });
});
