export type ModernizationRoute = {
  id: "workflow" | "application";
  title: string;
  statement: string;
  signals: readonly string[];
  output: string;
};

export type MethodStep = {
  id: "scope" | "map" | "simplify" | "build" | "verify" | "transfer";
  title: string;
  description: string;
  artifact: string;
};

export const modernizationRoutes = [
  {
    id: "workflow",
    title: "Workflowmodernisering",
    statement: "Van handwerk naar een beheersbare workflow.",
    signals: [
      "Informatie beweegt via inboxen en spreadsheets.",
      "Uitzonderingen worden laat of niet zichtbaar.",
      "Dezelfde gegevens worden op meerdere plekken bijgehouden.",
    ],
    output: "Een eenvoudiger proces met zichtbare controles, eigenaarschap en overdracht.",
  },
  {
    id: "application",
    title: "Applicatiemodernisering",
    statement: "Van kwetsbare legacy naar software die weer vooruit kan.",
    signals: [
      "Wijzigingen zijn risicovol of disproportioneel duur.",
      "Dependencies, integraties of documentatie zijn onduidelijk.",
      "Kennis en continuïteit hangen van één persoon of leverancier af.",
    ],
    output: "Een gefaseerde moderniseringsroute zonder automatische volledige herbouw.",
  },
] as const satisfies readonly ModernizationRoute[];

export const methodSteps = [
  {
    id: "scope",
    title: "Scope",
    description: "Maak doel, context, beslissers en grenzen expliciet voordat onderzoek begint.",
    artifact: "Scopekader en beslisvraag",
  },
  {
    id: "map",
    title: "Map",
    description: "Breng proces, data, systemen, risico en eigenaarschap samen in één current-state map.",
    artifact: "Proces- en afhankelijkhedenkaart",
  },
  {
    id: "simplify",
    title: "Simplify",
    description: "Verwijder onnodige stappen en aannames voordat techniek extra complexiteit toevoegt.",
    artifact: "Beslislog en oplossingsrichtingen",
  },
  {
    id: "build",
    title: "Build",
    description: "Voer alleen de afgebakende verbetering uit die aantoonbaar bijdraagt aan het doel.",
    artifact: "Werkende, begrensde moderniseringsstap",
  },
  {
    id: "verify",
    title: "Verify",
    description: "Toets gedrag, risico, acceptatie en uitzonderingen tegen vooraf zichtbare criteria.",
    artifact: "Acceptatie- en controlebewijs",
  },
  {
    id: "transfer",
    title: "Transfer",
    description: "Leg besluiten en werking vast zodat het team niet afhankelijk blijft van een black box.",
    artifact: "Documentatie en overdrachtsset",
  },
] as const satisfies readonly MethodStep[];

export const bannedMarketingPhrases = [
  "Transformeer je bedrijf met AI",
  "Unlock the power of innovation",
  "Empowering businesses",
  "Seamless solutions",
  "Cutting-edge technology",
  "Future-proof je organisatie",
] as const;
