import type { Metadata } from "next";

import { RebrandPage } from "@/components/rebrand/RebrandPage";

export const metadata: Metadata = {
  title: "Workflow- en applicatiemodernisering",
  description:
    "Prototype: Digitech Solutions brengt procesfrictie en verouderde applicaties terug naar een beheersbare moderniseringsroute.",
  robots: {
    index: false,
    follow: false,
    nocache: true,
    googleBot: {
      index: false,
      follow: false,
      noimageindex: true,
    },
  },
};

export default function RebrandPrototypeRoute() {
  return <RebrandPage />;
}
