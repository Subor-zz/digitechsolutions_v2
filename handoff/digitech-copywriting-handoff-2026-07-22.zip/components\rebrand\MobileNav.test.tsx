// @vitest-environment jsdom

import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it } from "vitest";

import { MobileNav } from "./MobileNav";

afterEach(cleanup);

describe("MobileNav", () => {
  it("opens, closes after navigation, and exposes its state", () => {
    render(<MobileNav />);

    const toggle = screen.getByRole("button", { name: "Menu" });
    expect(toggle.getAttribute("aria-expanded")).toBe("false");

    fireEvent.click(toggle);
    expect(toggle.getAttribute("aria-expanded")).toBe("true");
    expect(screen.getByRole("navigation", { name: "Mobiele navigatie" })).toBeTruthy();

    fireEvent.click(screen.getByRole("link", { name: "Diagnose" }));
    expect(toggle.getAttribute("aria-expanded")).toBe("false");
  });

  it("closes with Escape", () => {
    render(<MobileNav />);

    const toggle = screen.getByRole("button", { name: "Menu" });
    fireEvent.click(toggle);
    fireEvent.keyDown(window, { key: "Escape" });

    expect(toggle.getAttribute("aria-expanded")).toBe("false");
  });
});
